# Build The tpg366 Native Worker

Extract this archive into a regular directory and run Cargo from its root.
No plugin directory, Python runtime, Explorer installation, or vendor SDK
is needed to compile the Rust source. DLL-backed workers still require their
separately supplied SDK DLL when run against real hardware.

## Prerequisites

Use Rust >= 1.89, Cargo, the selected Rust standard-library
target, and its platform compiler/linker and system libraries. These toolchain
components are not vendored here. No Rust tests or deployed executable is
included. Generated ABI bindings and the error catalog are already included.

The required registry source union is included under `vendor/`. The local
`.cargo/config.toml` replaces crates.io for an offline build. The worker
manifest and build lock are specialized to this family; originals are
retained under `provenance/`. Implementation source files are unchanged.
Extra registry packages marked `resolution-only` satisfy Cargo's inactive
target resolution and are not linked for the two supported platforms.

## Family Builds

```sh
cargo build --locked --offline --release --no-default-features --features tpg366 --target x86_64-unknown-linux-gnu
cargo build --locked --offline --release --no-default-features --features tpg366 --target x86_64-pc-windows-gnu
```

Linux requires a C linker. Windows GNU requires the matching MinGW-w64
compiler and import-library tools; cross builds may set the standard Cargo
target linker variables. `zig-linker.py` and `zig-dlltool.py` are optional
build-time helpers for an explicitly installed Zig and Python 3, not worker
runtime dependencies. See their source before choosing that alternate linker.

Only `tpg366` is enabled. Never omit `--no-default-features`, enable
`test-backend`, or deploy a development fault-injection binary. The native
worker's protocol expects a supervising Explorer adapter; compiling or
running it is not a hardware-validation claim.

## Provenance

`SOURCE_MANIFEST.json` records dependency versions, registry archive checksums,
license files, and the SHA-256 of every other archive file. Its source-data
SHA-256 hashes the original native project file records before manifest/lock
specialization. The archive-data SHA-256 covers the sorted archive records,
independently of ZIP compression.
`LICENSES.md` distinguishes ported plugin terms and third-party licenses from
vendor SDK terms. Full upstream texts are retained in `THIRD_PARTY_NOTICES.txt`
and `third_party/licenses/`; no SDK redistribution rights are granted.
